"""
SLOPE/W Strength Calibration
================================
Calibrates c' and phi' for AWYC and WYC against the Nov 2020 slope failure,
using pore pressures from the calibrated SEEP/W model.

Parameters calibrated:
  c_AWYC   : cohesion of Weathered Yazoo Clay in Active Zone (psf)
  phi_AWYC : friction angle of AWYC (degrees)
  c_WYC    : cohesion of Weathered Yazoo Clay (psf)
  phi_WYC  : friction angle of WYC (degrees)

Fixed (forensic study values):
  SC  - Silty Clay        : c=198.4 psf, phi=20.0 deg
  UYC - Unweathered Yazoo : c=384.2 psf, phi=20.0 deg

Objective:
  Minimise (FS - 1.0)^2 at the end of Oct-Nov 2020 rainfall event.
  SEEP/W is re-run each trial (KSat/KYX locked at calibrated values) so pore
  pressures are physically consistent with each strength trial.

Key design notes:
  - Base GSZ: Metro-Center-calibrated-slope.gsz
      Root XML already has KSat_WYC=5.64e-6, KYX_AWYC=80827 (calibrated)
      Results CSVs inside are STALE (pre-calibration solve) — solver re-runs all
  - Rainfall: Oct-Nov 2020 from S2.csv, weekly aggregation (9 steps)
  - FS eval : pore pressures at last SEEP/W weekly step (peak wetness)
  - FS read : FS/001/slip_surface.csv → min(SlipFOS); fallback to lambdafos

Usage:
    python calibrate_slope.py
"""

import sys, os, glob, shutil, zipfile, csv, re, warnings, subprocess, time
import numpy as np
import pandas as pd
from scipy.optimize import minimize

warnings.filterwarnings("ignore")

sys.path.insert(0, r'C:\Users\Zaman\AppData\Roaming\Python\Python314\site-packages')

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------

CALIB_DIR  = r"E:\Github\MCP_Geostudio\calibration"
BASE_GSZ   = os.path.join(CALIB_DIR, "Metro-Center-calibrated.gsz")   # output of calibrate_seep.py
SENSOR_CSV = os.path.join(CALIB_DIR, "S2.csv")
OUT_DIR    = CALIB_DIR
LOG_CSV    = os.path.join(OUT_DIR, "slope_calibration_trial_log.csv")
OUT_GSZ    = os.path.join(OUT_DIR, "Metro-Center-slope-final.gsz")

# Calibration window (must match SEEP/W calibration)
CALIB_START = "2020-10-01"
CALIB_END   = "2020-11-30"

# Analysis names
SEEP_INITIAL   = "Initial Condition"
SEEP_TRANSIENT = "Rainfall Simulation"
SLOPE_FS       = "FS"
ANALYSIS_FOLDERS = [SEEP_INITIAL, SEEP_TRANSIENT, "Slope Stability", SLOPE_FS]

# SEEP/W start time (5-day initial condition)
SIMULATION_START_S = 432000

# ---------------------------------------------------------------------------
# Baseline strength parameters — forensic study values (from Metro-Center-calibrated.gsz)
# AWYC and WYC are calibrated; SC and UYC are held fixed.
# ---------------------------------------------------------------------------
C_AWYC_BASE   =  79.3    # psf  (forensic study value)
PHI_AWYC_BASE =  19.0    # deg
C_WYC_BASE    = 248.5    # psf
PHI_WYC_BASE  =  19.0    # deg

# Search bounds
C_AWYC_MIN,   C_AWYC_MAX   =   0.0, 250.0
PHI_AWYC_MIN, PHI_AWYC_MAX =  10.0,  25.0
C_WYC_MIN,    C_WYC_MAX    =  50.0, 500.0
PHI_WYC_MIN,  PHI_WYC_MAX  =  12.0,  25.0

FS_TARGET      = 1.0
MAX_OPT_ITER   = 100
SOLVER_TIMEOUT = 1800   # seconds per trial


# ---------------------------------------------------------------------------
# Solver detection
# ---------------------------------------------------------------------------

def find_solver():
    patterns = [
        r"C:\Program Files\Seequent\GeoStudio 2025.2\Bin\GeoCmd.exe",
        r"C:\Program Files\Seequent\GeoStudio 2024.2\Bin\GeoCmd.exe",
        r"C:\Program Files\Seequent\GeoStudio*\Bin\GeoCmd.exe",
        r"C:\Program Files\GeoSlope\GeoStudio*\GeoCmd.exe",
    ]
    for p in patterns:
        hits = sorted(glob.glob(p))
        if hits:
            return hits[-1]
    return None


# ---------------------------------------------------------------------------
# Rainfall (weekly aggregation — identical to calibrate_seep.py)
# ---------------------------------------------------------------------------

def load_rainfall():
    df = pd.read_csv(SENSOR_CSV, low_memory=False)
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp"])
    df["Precipitation"] = pd.to_numeric(df["Precipitation"], errors="coerce")
    crest  = df[df["position"] == "Crest"].copy().set_index("timestamp")
    daily  = crest[["Precipitation"]].resample("D").sum()
    daily  = daily.loc[CALIB_START:CALIB_END]
    weekly = daily["Precipitation"].resample("W").sum()
    mm_to_in = 1.0 / 25.4
    points, t0 = [], daily.index[0]
    for ts, total_mm in weekly.items():
        elapsed_s = int((ts - t0).total_seconds())
        points.append({"X": str(elapsed_s), "Y": (total_mm * mm_to_in) / 7.0})
    print(f"  {len(points)} weekly rainfall points  "
          f"({daily.index[0].date()} → {daily.index[-1].date()})")
    return points


# ---------------------------------------------------------------------------
# XML patching
# ---------------------------------------------------------------------------

def patch_material_strength(xml_str, mat_name, new_c, new_phi):
    """Find the <Material> block by name and replace CohesionPrime / PhiPrime."""
    pat = rf'(<Material>.*?<Name>{re.escape(mat_name)}</Name>.*?</Material>)'
    m   = re.search(pat, xml_str, re.DOTALL)
    if not m:
        print(f"  WARNING: material '{mat_name}' not found in XML")
        return xml_str
    block     = m.group(1)
    new_block = re.sub(r'<CohesionPrime>[^<]*</CohesionPrime>',
                       f'<CohesionPrime>{new_c:.2f}</CohesionPrime>', block)
    new_block = re.sub(r'<PhiPrime>[^<]*</PhiPrime>',
                       f'<PhiPrime>{new_phi:.2f}</PhiPrime>', new_block)
    return xml_str[:m.start()] + new_block + xml_str[m.end():]


def patch_rainfall_xml(xml_str, rain_points):
    pos = xml_str.find("<Name>rainfall</Name>")
    if pos == -1:
        print("  WARNING: rainfall function not found")
        return xml_str
    pts_open  = xml_str.find("<Points", pos)
    pts_close = xml_str.find("</Points>", pts_open) + len("</Points>")
    new_pts   = f'<Points Len="{len(rain_points)}">\n'
    for pt in rain_points:
        new_pts += f'            <Point X="{pt["X"]}" Y="{pt["Y"]:.8f}" />\n'
    new_pts += "          </Points>"
    return xml_str[:pts_open] + new_pts + xml_str[pts_close:]


def patch_duration_xml(xml_str, n_weeks, start_s=432000):
    """Patch Rainfall Simulation to n_weeks of weekly save steps."""
    week_s     = 7 * 86400
    duration_s = n_weeks * week_s
    steps_xml  = "\n".join(
        f'          <TimeStep Step="{week_s}" ElapsedTime="{start_s + w * week_s}" Save="true" />'
        for w in range(1, n_weeks + 1)
    )
    new_block = (
        f"<TimeIncrements>\n"
        f"        <Start>{start_s}</Start>\n"
        f"        <Duration>{duration_s}</Duration>\n"
        f"        <IncrementOption>Exponential</IncrementOption>\n"
        f"        <IncrementCount>{n_weeks}</IncrementCount>\n"
        f"        <TimeSteps Len=\"{n_weeks}\">\n"
        f"{steps_xml}\n"
        f"        </TimeSteps>\n"
        f"      </TimeIncrements>"
    )
    rs = xml_str.find("<Name>Rainfall Simulation</Name>")
    if rs == -1:
        print("  WARNING: Rainfall Simulation not found")
        return xml_str
    ti_s = xml_str.find("<TimeIncrements>", rs)
    ti_e = xml_str.find("</TimeIncrements>", ti_s) + len("</TimeIncrements>")
    return xml_str[:ti_s] + new_block + xml_str[ti_e:]


def patch_fs_timestep(xml_str, n_weeks, start_s=432000):
    """Update FS analysis to reference the LAST SEEP/W weekly step (peak pore pressure)."""
    week_s       = 7 * 86400
    last_elapsed = start_s + n_weeks * week_s
    duration_s   = n_weeks * week_s
    new_block = (
        f"<TimeIncrements>\n"
        f"        <Start>{start_s}</Start>\n"
        f"        <Duration>{duration_s}</Duration>\n"
        f"        <TimeSteps Len=\"1\">\n"
        f"          <TimeStep Step=\"{duration_s}\" ElapsedTime=\"{last_elapsed}\" Save=\"true\" />\n"
        f"        </TimeSteps>\n"
        f"      </TimeIncrements>"
    )
    fs_pos = xml_str.find("<Name>FS</Name>")
    if fs_pos == -1:
        print("  WARNING: FS analysis not found")
        return xml_str
    ti_s = xml_str.find("<TimeIncrements>", fs_pos)
    ti_e = xml_str.find("</TimeIncrements>", ti_s) + len("</TimeIncrements>")
    return xml_str[:ti_s] + new_block + xml_str[ti_e:]


# ---------------------------------------------------------------------------
# Prepare trial GSZ
# ---------------------------------------------------------------------------

def prepare_trial_gsz(trial_idx, c_awyc, phi_awyc, c_wyc, phi_wyc, rain_points):
    temp_dir = os.path.join(OUT_DIR, f"_slope_{trial_idx:04d}")
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir)

    temp_gsz = os.path.join(temp_dir, os.path.basename(BASE_GSZ))
    shutil.copy2(BASE_GSZ, temp_gsz)

    with zipfile.ZipFile(temp_gsz, "r") as zin:
        all_items = zin.infolist()
        all_data  = {item.filename: zin.read(item.filename) for item in all_items}

    root_xml_key = next(
        (k for k in all_data
         if k.endswith(".xml") and not any(k.startswith(af + "/") for af in ANALYSIS_FOLDERS)),
        None
    )
    if root_xml_key is None:
        raise RuntimeError("Root XML not found in base GSZ")

    xml_stem = os.path.splitext(os.path.basename(root_xml_key))[0]
    xml_str  = all_data[root_xml_key].decode("utf-8")

    xml_str = patch_material_strength(xml_str, "Weathered Yazoo Clay in Active Zone", c_awyc, phi_awyc)
    xml_str = patch_material_strength(xml_str, "Weathered Yazoo Clay",                c_wyc,  phi_wyc)
    xml_str = patch_rainfall_xml(xml_str, rain_points)
    xml_str = patch_duration_xml(xml_str, len(rain_points))
    xml_str = patch_fs_timestep(xml_str,  len(rain_points))

    with zipfile.ZipFile(temp_gsz, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for item in all_items:
            fname = item.filename
            data  = all_data[fname]
            if xml_stem + ".xml" in fname:
                fixed_name = xml_stem + ".xml"
                for af in ANALYSIS_FOLDERS:
                    if fname.startswith(af + "/") or ("/" + af + "/") in fname:
                        fixed_name = af + "/" + xml_stem + ".xml"
                        break
                item.filename = fixed_name
                if fixed_name == xml_stem + ".xml":
                    data = xml_str.encode("utf-8")
            zout.writestr(item, data)

    return temp_gsz, temp_dir


# ---------------------------------------------------------------------------
# Run solver
# ---------------------------------------------------------------------------

def run_solver(solver_exe, temp_gsz):
    result = subprocess.run(
        [solver_exe, "/solve", temp_gsz],
        capture_output=True, text=True, timeout=SOLVER_TIMEOUT
    )
    if result.returncode != 0:
        raise RuntimeError(f"Solver error {result.returncode}: {result.stderr or result.stdout}")


# ---------------------------------------------------------------------------
# Read critical FS from solved archive
# ---------------------------------------------------------------------------

def read_critical_fs(temp_gsz):
    """
    Read the critical (minimum) FS from the solved SLOPE/W archive.
    Primary  : FS/001/slip_surface.csv  → min valid SlipFOS
    Fallback : FS/001/lambdafos_*.csv   → average of converged FOS_Force, FOS_Moment
    """
    try:
        with zipfile.ZipFile(temp_gsz, "r") as z:
            files = z.namelist()

            # Primary: slip_surface.csv
            ss_key = "FS/001/slip_surface.csv"
            if ss_key in files:
                fos_vals = []
                for row in csv.DictReader(z.read(ss_key).decode("utf-8").splitlines()):
                    try:
                        fos = float(row["SlipFOS"])
                        if 0.1 < fos < 100:
                            fos_vals.append(fos)
                    except (ValueError, KeyError):
                        continue
                if fos_vals:
                    return min(fos_vals)

            # Fallback: lambdafos_*.csv
            lf_keys = [f for f in files if "lambdafos" in f and f.startswith("FS/001/")]
            if lf_keys:
                rows = list(csv.DictReader(z.read(lf_keys[0]).decode("utf-8").splitlines()))
                valid = [(float(r["FOSByForce"]), float(r["FOSByMoment"])) for r in rows
                         if r.get("FOSByForce") and r.get("FOSByMoment")]
                if valid:
                    best = min(valid, key=lambda r: abs(r[0] - r[1]))
                    return (best[0] + best[1]) / 2.0

    except Exception as e:
        print(f"  WARNING: could not read FS — {e}")
    return None


# ---------------------------------------------------------------------------
# Objective function
# ---------------------------------------------------------------------------

iter_count = [0]
trial_log  = []


def objective(params, solver, rain_points):
    c_awyc, phi_awyc, c_wyc, phi_wyc = params

    c_awyc   = float(np.clip(c_awyc,   C_AWYC_MIN,   C_AWYC_MAX))
    phi_awyc = float(np.clip(phi_awyc, PHI_AWYC_MIN, PHI_AWYC_MAX))
    c_wyc    = float(np.clip(c_wyc,    C_WYC_MIN,    C_WYC_MAX))
    phi_wyc  = float(np.clip(phi_wyc,  PHI_WYC_MIN,  PHI_WYC_MAX))

    iter_count[0] += 1
    idx = iter_count[0]
    print(f"  Trial {idx:3d}: "
          f"c_AWYC={c_awyc:6.1f}  phi_AWYC={phi_awyc:5.2f}  "
          f"c_WYC={c_wyc:6.1f}  phi_WYC={phi_wyc:5.2f}")

    temp_dir = None
    try:
        temp_gsz, temp_dir = prepare_trial_gsz(
            idx, c_awyc, phi_awyc, c_wyc, phi_wyc, rain_points
        )
        run_solver(solver, temp_gsz)
        fs   = read_critical_fs(temp_gsz)
        cost = (fs - FS_TARGET) ** 2 if fs is not None else 9999.0

        if fs is None:
            print("    -> WARNING: FS unreadable — penalty applied")
        else:
            flag = "  ✓" if abs(fs - FS_TARGET) < 0.02 else ""
            print(f"    -> FS = {fs:.4f}  |FS-1.0| = {abs(fs-FS_TARGET):.4f}{flag}")

        trial_log.append({
            "trial":    idx,
            "c_awyc":   round(c_awyc,   2),
            "phi_awyc": round(phi_awyc, 3),
            "c_wyc":    round(c_wyc,    2),
            "phi_wyc":  round(phi_wyc,  3),
            "fs":       round(fs, 5) if fs else 9999,
            "cost":     round(cost, 8),
        })
        return cost

    except Exception as e:
        print(f"    -> FAILED: {e}")
        trial_log.append({
            "trial":    idx,
            "c_awyc":   round(c_awyc,   2),
            "phi_awyc": round(phi_awyc, 3),
            "c_wyc":    round(c_wyc,    2),
            "phi_wyc":  round(phi_wyc,  3),
            "fs":       9999, "cost": 9999.0,
        })
        return 9999.0

    finally:
        if temp_dir:
            _cleanup(temp_dir)


def _cleanup(temp_dir):
    for _ in range(8):
        try:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            return
        except Exception:
            time.sleep(2)


# ---------------------------------------------------------------------------
# Save final GSZ
# ---------------------------------------------------------------------------

def save_calibrated_gsz(c_awyc, phi_awyc, c_wyc, phi_wyc, rain_points):
    shutil.copy2(BASE_GSZ, OUT_GSZ)

    with zipfile.ZipFile(OUT_GSZ, "r") as zin:
        all_items = zin.infolist()
        all_data  = {item.filename: zin.read(item.filename) for item in all_items}

    root_xml_key = next(
        (k for k in all_data
         if k.endswith(".xml") and not any(k.startswith(af + "/") for af in ANALYSIS_FOLDERS)),
        None
    )
    if root_xml_key is None:
        print("WARNING: could not save — root XML not found")
        return

    xml_stem = os.path.splitext(os.path.basename(root_xml_key))[0]
    xml_str  = all_data[root_xml_key].decode("utf-8")
    xml_str  = patch_material_strength(xml_str, "Weathered Yazoo Clay in Active Zone", c_awyc, phi_awyc)
    xml_str  = patch_material_strength(xml_str, "Weathered Yazoo Clay",                c_wyc,  phi_wyc)
    xml_str  = patch_rainfall_xml(xml_str, rain_points)
    xml_str  = patch_duration_xml(xml_str, len(rain_points))
    xml_str  = patch_fs_timestep(xml_str,  len(rain_points))

    with zipfile.ZipFile(OUT_GSZ, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for item in all_items:
            fname = item.filename
            data  = all_data[fname]
            if xml_stem + ".xml" in fname:
                fixed_name = xml_stem + ".xml"
                for af in ANALYSIS_FOLDERS:
                    if fname.startswith(af + "/") or ("/" + af + "/") in fname:
                        fixed_name = af + "/" + xml_stem + ".xml"
                        break
                item.filename = fixed_name
                if fixed_name == xml_stem + ".xml":
                    data = xml_str.encode("utf-8")
            zout.writestr(item, data)

    print(f"\nFinal calibrated GSZ saved to: {OUT_GSZ}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print("=" * 65)
    print("SLOPE/W Strength Calibration — Metro-Center")
    print(f"  Base GSZ    : {os.path.basename(BASE_GSZ)}")
    print(f"  Cal window  : {CALIB_START}  →  {CALIB_END}")
    print(f"  FS target   : {FS_TARGET}  (failure condition)")
    print(f"  Calibrated  : AWYC (c, phi)  |  WYC (c, phi)")
    print(f"  Fixed       : SC (198.4 psf, 20°)  |  UYC (384.2 psf, 20°)")
    print(f"  Max trials  : {MAX_OPT_ITER}")
    print("=" * 65)

    for path, label in [(BASE_GSZ, "Base GSZ"), (SENSOR_CSV, "Sensor CSV")]:
        if not os.path.exists(path):
            print(f"\nERROR: {label} not found at {path}")
            sys.exit(1)

    solver = find_solver()
    if solver is None:
        print("\nERROR: GeoStudio solver not found.")
        sys.exit(1)
    print(f"\n  Solver: {solver}")

    print("\nLoading calibration rainfall...")
    rain_points = load_rainfall()

    n_weeks    = len(rain_points)
    last_t     = SIMULATION_START_S + n_weeks * 7 * 86400

    x0 = np.array([C_AWYC_BASE, PHI_AWYC_BASE, C_WYC_BASE, PHI_WYC_BASE])
    print(f"\nStarting parameters (warm-start from current model):")
    print(f"  c_AWYC   = {x0[0]:.1f} psf    bounds [{C_AWYC_MIN}, {C_AWYC_MAX}]")
    print(f"  phi_AWYC = {x0[1]:.2f}°       bounds [{PHI_AWYC_MIN}, {PHI_AWYC_MAX}]")
    print(f"  c_WYC    = {x0[2]:.1f} psf    bounds [{C_WYC_MIN}, {C_WYC_MAX}]")
    print(f"  phi_WYC  = {x0[3]:.2f}°       bounds [{PHI_WYC_MIN}, {PHI_WYC_MAX}]")
    print(f"\n  SEEP/W  : {n_weeks} weekly steps, last step at t={last_t}s")
    print(f"  FS eval : pore pressures at t={last_t}s (end of Oct-Nov 2020 event)")
    print(f"\nRunning optimisation (max {MAX_OPT_ITER} trials)...\n")

    result = minimize(
        objective,
        x0,
        args=(solver, rain_points),
        method="Nelder-Mead",
        options={
            "maxiter": MAX_OPT_ITER,
            "xatol":   0.5,    # 0.5 psf or 0.5 degrees
            "fatol":   1e-4,   # |FS - 1.0| < 0.01
            "disp":    True,
        }
    )

    best_c_awyc, best_phi_awyc, best_c_wyc, best_phi_wyc = result.x

    # Pick the best trial from the log (most reliable)
    valid = [t for t in trial_log if t["fs"] < 900]
    if valid:
        best = min(valid, key=lambda t: abs(t["fs"] - FS_TARGET))
        best_c_awyc   = best["c_awyc"]
        best_phi_awyc = best["phi_awyc"]
        best_c_wyc    = best["c_wyc"]
        best_phi_wyc  = best["phi_wyc"]
        best_fs       = best["fs"]
    else:
        best_fs = None

    print(f"\n{'=' * 65}")
    print("Optimisation complete")
    print(f"  Status   : {result.message}")
    print(f"  Trials   : {result.nit}")
    if best_fs:
        print(f"  Best FS  : {best_fs:.4f}  (|FS-1.0| = {abs(best_fs-FS_TARGET):.4f})")
    print()
    print(f"  {'Parameter':<22} {'Baseline':>12}  {'Calibrated':>12}  {'Change':>10}")
    print(f"  {'-'*62}")
    print(f"  {'c_AWYC (psf)':<22} {C_AWYC_BASE:>12.1f}  {best_c_awyc:>12.1f}  "
          f"{best_c_awyc - C_AWYC_BASE:>+10.1f}")
    print(f"  {'phi_AWYC (deg)':<22} {PHI_AWYC_BASE:>12.2f}  {best_phi_awyc:>12.2f}  "
          f"{best_phi_awyc - PHI_AWYC_BASE:>+10.2f}")
    print(f"  {'c_WYC (psf)':<22} {C_WYC_BASE:>12.1f}  {best_c_wyc:>12.1f}  "
          f"{best_c_wyc - C_WYC_BASE:>+10.1f}")
    print(f"  {'phi_WYC (deg)':<22} {PHI_WYC_BASE:>12.2f}  {best_phi_wyc:>12.2f}  "
          f"{best_phi_wyc - PHI_WYC_BASE:>+10.2f}")

    if trial_log:
        with open(LOG_CSV, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=trial_log[0].keys())
            writer.writeheader()
            writer.writerows(trial_log)
        print(f"\nTrial log saved to: {LOG_CSV}")

    save_calibrated_gsz(best_c_awyc, best_phi_awyc, best_c_wyc, best_phi_wyc, rain_points)

    for item in os.listdir(OUT_DIR):
        if item.startswith("_slope_"):
            _cleanup(os.path.join(OUT_DIR, item))

    print("\nDone.")


if __name__ == "__main__":
    main()
