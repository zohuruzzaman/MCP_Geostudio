from google.protobuf import struct_pb2 as _struct_pb2
import gsi_DataParam_Type_pb2 as _gsi_DataParam_Type_pb2
import gsi_Result_Type_pb2 as _gsi_Result_Type_pb2
import gsi_UnitCategory_Type_pb2 as _gsi_UnitCategory_Type_pb2
import gsi_Point_pb2 as _gsi_Point_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetRequest(_message.Message):
    __slots__ = ("analysis", "object")
    ANALYSIS_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    analysis: str
    object: str
    def __init__(self, analysis: _Optional[str] = ..., object: _Optional[str] = ...) -> None: ...

class GetResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _struct_pb2.Value
    def __init__(self, data: _Optional[_Union[_struct_pb2.Value, _Mapping]] = ...) -> None: ...

class SetRequest(_message.Message):
    __slots__ = ("analysis", "object", "data")
    ANALYSIS_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    analysis: str
    object: str
    data: _struct_pb2.Value
    def __init__(self, analysis: _Optional[str] = ..., object: _Optional[str] = ..., data: _Optional[_Union[_struct_pb2.Value, _Mapping]] = ...) -> None: ...

class SetResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class AddRequest(_message.Message):
    __slots__ = ("analysis", "object", "data")
    ANALYSIS_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    analysis: str
    object: str
    data: _struct_pb2.Value
    def __init__(self, analysis: _Optional[str] = ..., object: _Optional[str] = ..., data: _Optional[_Union[_struct_pb2.Value, _Mapping]] = ...) -> None: ...

class AddResponse(_message.Message):
    __slots__ = ("object",)
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    object: str
    def __init__(self, object: _Optional[str] = ...) -> None: ...

class DeleteRequest(_message.Message):
    __slots__ = ("analysis", "object", "force_delete")
    ANALYSIS_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    FORCE_DELETE_FIELD_NUMBER: _ClassVar[int]
    analysis: str
    object: str
    force_delete: bool
    def __init__(self, analysis: _Optional[str] = ..., object: _Optional[str] = ..., force_delete: bool = ...) -> None: ...

class DeleteResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SolveAnalysesRequest(_message.Message):
    __slots__ = ("analyses", "step", "solve_dependencies")
    ANALYSES_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    SOLVE_DEPENDENCIES_FIELD_NUMBER: _ClassVar[int]
    analyses: _containers.RepeatedScalarFieldContainer[str]
    step: int
    solve_dependencies: bool
    def __init__(self, analyses: _Optional[_Iterable[str]] = ..., step: _Optional[int] = ..., solve_dependencies: bool = ...) -> None: ...

class SolveAnalysesResponse(_message.Message):
    __slots__ = ("completion_status", "all_succeeded")
    class CompletionStatusEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: SolveAnalysesResult
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[SolveAnalysesResult, _Mapping]] = ...) -> None: ...
    COMPLETION_STATUS_FIELD_NUMBER: _ClassVar[int]
    ALL_SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    completion_status: _containers.MessageMap[str, SolveAnalysesResult]
    all_succeeded: bool
    def __init__(self, completion_status: _Optional[_Mapping[str, SolveAnalysesResult]] = ..., all_succeeded: bool = ...) -> None: ...

class SolveAnalysesResult(_message.Message):
    __slots__ = ("succeeded", "error_message")
    SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    succeeded: bool
    error_message: str
    def __init__(self, succeeded: bool = ..., error_message: _Optional[str] = ...) -> None: ...

class QueryTableParamsInfoRequest(_message.Message):
    __slots__ = ("analysis", "table")
    ANALYSIS_FIELD_NUMBER: _ClassVar[int]
    TABLE_FIELD_NUMBER: _ClassVar[int]
    analysis: str
    table: _gsi_Result_Type_pb2.Type
    def __init__(self, analysis: _Optional[str] = ..., table: _Optional[_Union[_gsi_Result_Type_pb2.Type, str]] = ...) -> None: ...

class QueryTableParamsInfoResponse(_message.Message):
    __slots__ = ("params_info",)
    PARAMS_INFO_FIELD_NUMBER: _ClassVar[int]
    params_info: _containers.RepeatedCompositeFieldContainer[ParamInfo]
    def __init__(self, params_info: _Optional[_Iterable[_Union[ParamInfo, _Mapping]]] = ...) -> None: ...

class ParamInfo(_message.Message):
    __slots__ = ("dataparam", "key", "display", "unit_category", "vector_components", "units")
    DATAPARAM_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_FIELD_NUMBER: _ClassVar[int]
    UNIT_CATEGORY_FIELD_NUMBER: _ClassVar[int]
    VECTOR_COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    UNITS_FIELD_NUMBER: _ClassVar[int]
    dataparam: _gsi_DataParam_Type_pb2.Type
    key: str
    display: str
    unit_category: _gsi_UnitCategory_Type_pb2.Type
    vector_components: _containers.RepeatedScalarFieldContainer[_gsi_DataParam_Type_pb2.Type]
    units: str
    def __init__(self, dataparam: _Optional[_Union[_gsi_DataParam_Type_pb2.Type, str]] = ..., key: _Optional[str] = ..., display: _Optional[str] = ..., unit_category: _Optional[_Union[_gsi_UnitCategory_Type_pb2.Type, str]] = ..., vector_components: _Optional[_Iterable[_Union[_gsi_DataParam_Type_pb2.Type, str]]] = ..., units: _Optional[str] = ...) -> None: ...

class QueryResultsRequest(_message.Message):
    __slots__ = ("analysis", "step", "run", "instance", "table", "dataparams", "result_ids")
    ANALYSIS_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    INSTANCE_FIELD_NUMBER: _ClassVar[int]
    TABLE_FIELD_NUMBER: _ClassVar[int]
    DATAPARAMS_FIELD_NUMBER: _ClassVar[int]
    RESULT_IDS_FIELD_NUMBER: _ClassVar[int]
    analysis: str
    step: int
    run: int
    instance: int
    table: _gsi_Result_Type_pb2.Type
    dataparams: _containers.RepeatedScalarFieldContainer[_gsi_DataParam_Type_pb2.Type]
    result_ids: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, analysis: _Optional[str] = ..., step: _Optional[int] = ..., run: _Optional[int] = ..., instance: _Optional[int] = ..., table: _Optional[_Union[_gsi_Result_Type_pb2.Type, str]] = ..., dataparams: _Optional[_Iterable[_Union[_gsi_DataParam_Type_pb2.Type, str]]] = ..., result_ids: _Optional[_Iterable[int]] = ...) -> None: ...

class QueryResultsResponse(_message.Message):
    __slots__ = ("results",)
    class ResultsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: ParamResults
        def __init__(self, key: _Optional[int] = ..., value: _Optional[_Union[ParamResults, _Mapping]] = ...) -> None: ...
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.MessageMap[int, ParamResults]
    def __init__(self, results: _Optional[_Mapping[int, ParamResults]] = ...) -> None: ...

class QueryResultsAtCoordinatesRequest(_message.Message):
    __slots__ = ("analysis", "step", "run", "instance", "dataparams", "points")
    ANALYSIS_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATAPARAMS_FIELD_NUMBER: _ClassVar[int]
    POINTS_FIELD_NUMBER: _ClassVar[int]
    analysis: str
    step: int
    run: int
    instance: int
    dataparams: _containers.RepeatedScalarFieldContainer[_gsi_DataParam_Type_pb2.Type]
    points: _containers.RepeatedCompositeFieldContainer[_gsi_Point_pb2.Point]
    def __init__(self, analysis: _Optional[str] = ..., step: _Optional[int] = ..., run: _Optional[int] = ..., instance: _Optional[int] = ..., dataparams: _Optional[_Iterable[_Union[_gsi_DataParam_Type_pb2.Type, str]]] = ..., points: _Optional[_Iterable[_Union[_gsi_Point_pb2.Point, _Mapping]]] = ...) -> None: ...

class QueryResultsAtCoordinatesResponse(_message.Message):
    __slots__ = ("results",)
    class ResultsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: ParamResults
        def __init__(self, key: _Optional[int] = ..., value: _Optional[_Union[ParamResults, _Mapping]] = ...) -> None: ...
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.MessageMap[int, ParamResults]
    def __init__(self, results: _Optional[_Mapping[int, ParamResults]] = ...) -> None: ...

class ParamResults(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, values: _Optional[_Iterable[float]] = ...) -> None: ...

class QueryResultsAvailabilityRequest(_message.Message):
    __slots__ = ("analysis",)
    ANALYSIS_FIELD_NUMBER: _ClassVar[int]
    analysis: str
    def __init__(self, analysis: _Optional[str] = ...) -> None: ...

class QueryResultsAvailabilityResponse(_message.Message):
    __slots__ = ("has_results",)
    HAS_RESULTS_FIELD_NUMBER: _ClassVar[int]
    has_results: bool
    def __init__(self, has_results: bool = ...) -> None: ...

class LoadResultsRequest(_message.Message):
    __slots__ = ("analysis",)
    ANALYSIS_FIELD_NUMBER: _ClassVar[int]
    analysis: str
    def __init__(self, analysis: _Optional[str] = ...) -> None: ...

class LoadResultsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
