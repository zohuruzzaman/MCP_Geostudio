from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class Type(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    Undefined: _ClassVar[Type]
    Nodes: _ClassVar[Type]
    Elements: _ClassVar[Type]
    Gauss: _ClassVar[Type]
    ElementNodes: _ClassVar[Type]
    Time: _ClassVar[Type]
    NodePair: _ClassVar[Type]
    History: _ClassVar[Type]
    TimeStep: _ClassVar[Type]
    FlowPath: _ClassVar[Type]
    Slip: _ClassVar[Type]
    CriticalSlip: _ClassVar[Type]
    Column: _ClassVar[Type]
    Intercolumn: _ClassVar[Type]
    LambdaFOS: _ClassVar[Type]
    Reinforcement: _ClassVar[Type]
    Sample: _ClassVar[Type]
    Probabilistic: _ClassVar[Type]
    Iteration: _ClassVar[Type]
    BeamGauss: _ClassVar[Type]
    ParticleAir: _ClassVar[Type]
    ParticleWater: _ClassVar[Type]
    SavedTimeStep: _ClassVar[Type]
Undefined: Type
Nodes: Type
Elements: Type
Gauss: Type
ElementNodes: Type
Time: Type
NodePair: Type
History: Type
TimeStep: Type
FlowPath: Type
Slip: Type
CriticalSlip: Type
Column: Type
Intercolumn: Type
LambdaFOS: Type
Reinforcement: Type
Sample: Type
Probabilistic: Type
Iteration: Type
BeamGauss: Type
ParticleAir: Type
ParticleWater: Type
SavedTimeStep: Type
