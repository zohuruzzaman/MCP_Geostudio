#-------------------------------------------------------------------------------
# __init__.py
# This file is used to import the classes and functions from the protobuf subpackage in the gsi interface module.
# It adds its directory to the system path to include all protobuf files in the same directory.
#
# Copyright (C) 2025 Bentley Systems Inc. All rights reserved.
#----------------------------------------------------------------------------
import sys
import os
sys.path.append(os.path.dirname(__file__))

from .gsi_project_pb2_grpc import ProjectStub
from .gsi_project_pb2 import (
    SetRequest, SetResponse, GetRequest, GetResponse, QueryResultsRequest, QueryResultsAtCoordinatesRequest, 
    SolveAnalysesRequest, AddRequest, AddResponse, DeleteRequest, DeleteResponse, SolveAnalysesResponse, 
    QueryTableParamsInfoRequest, QueryTableParamsInfoResponse, ParamInfo, QueryResultsResponse, ParamResults, 
    QueryResultsAvailabilityRequest, QueryResultsAvailabilityResponse, LoadResultsRequest, LoadResultsResponse,
    QueryResultsAtCoordinatesResponse
    )
from .gsi_DataParam_Type_pb2 import Type as DataParamType
from .gsi_Result_Type_pb2 import Type as ResultType
from .gsi_UnitCategory_Type_pb2 import Type as UnitCategoryType
from .gsi_Point_pb2 import Point
from google.protobuf.struct_pb2 import Value