#----------------------------------------------------------------------------
# interface.py
#
# Interface for managing connections to the GeoStudio Server and gRPC calls.
#
# Copyright (C) 2025 Bentley Systems Inc. All rights reserved.
#----------------------------------------------------------------------------

import grpc
import os
import sys
import winreg  # Import the winreg module

from .protobuf import ProjectStub

COMPANY_NAME = "GEO-SLOPE"
REQUIRED_GEOSTUDIO_VERSION = "25.2"
PRODUCT_NAME = "GeoStudio"
IS_DEBUG = False # Set to True for debug mode or False for release mode
IS_PRIVATE = False # Set to True for private build or False for public build
PRODUCT = PRODUCT_NAME + " " + REQUIRED_GEOSTUDIO_VERSION + (" (Debug Build)" if IS_DEBUG else " (Private Build)" if IS_PRIVATE else "")

GSI_BINARY_DIRECTORY_64 = "GSI_BINARY_DIRECTORY_64"

def get_binaries_path_from_env():
    """
    Retrieves the path to the GeoStudio binaries stored in the environment variable.

    Returns:
        str: The path to the GeoStudio binaries.
    """
    return os.environ.get(GSI_BINARY_DIRECTORY_64)


def ensure_binaries_path_in_env():
    """
    Checks if the environment variable is set to a valid path. If not, retrieves the path to the GeoStudio binaries from the Windows registry
    and stores it in the environment variable.

    Raises:
        FileNotFoundError: If the path to the binaries does not exist.
        Exception: If the path to the binaries could not be read from the Windows registry.
    """
    bin_env = get_binaries_path_from_env()

    if not bin_env:
        try:
            registry_key_path = fr"SOFTWARE\{COMPANY_NAME}\{PRODUCT}"
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, registry_key_path)
            registry_value_name = "BinDir"
            path_to_binaries = winreg.QueryValueEx(key, registry_value_name)[0]
            if not os.path.exists(path_to_binaries):
                raise FileNotFoundError(f"Path to {PRODUCT_NAME} binaries does not exist: {path_to_binaries}")
            os.environ[GSI_BINARY_DIRECTORY_64] = path_to_binaries
        except Exception as e:
            raise Exception(f"{PRODUCT} is not installed on this machine or the registry key is missing.")
    elif not os.path.exists(bin_env):
        raise FileNotFoundError(f"Environment variable '{GSI_BINARY_DIRECTORY_64}' is set, but the path does not exist: {bin_env}")

# Retrieve the path and append it to sys.path
ensure_binaries_path_in_env()
sys.path.append(get_binaries_path_from_env())

import gsipy

class Project(ProjectStub):
    """
    Class that manages the connection to the GeoStudio Server and the gRPC calls.
    """
        
    def __init__(self, project_path=""):
        """
        Initializes the Project class.

        Args:
            project_path (str): The path to the project. Defaults to an empty string.
        """
        # Set the gRPC environment variables
        os.environ["GRPC_VERBOSITY"] = "NONE" 
        self.__connection = gsipy.ConnectionManager(project_path)        
        server_address = self.__connection.GRPCServerAddress()        
        channel = grpc.insecure_channel(server_address)        
        super().__init__(channel) # initialize project stub with the channel
    
    def Open(self, project_path: str):
        """
        Opens the project.

        Args:
            project_path (str): The path to the project.
        """
        self.__connection.Open(project_path)
    def Close(self):
        """
        Closes the project.
        """
        self.__connection.Close()
        
    def Save(self):
        """
        Saves the project.
        """
        self.__connection.Save()



def OpenProject(project_path: str):
    """
    Factory method to create and return a Project instance.

    Args:
        project_path (str): The path to the project.

    Returns:
        Project: An instance of the Project class.
    """
    return Project(project_path)

def NewProject():
    """
    Factory method to create and return a Project instance.

    Returns:
        Project: An instance of the Project class.
    """
    return Project()
